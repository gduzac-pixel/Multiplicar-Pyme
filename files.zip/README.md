# Multiplicar Pyme - PWA

Aplicación web progresiva para financiamiento de pymes en sectores: Agro, Petróleo y Minería.

## Instalación como App

### Android:
1. Abrí el link en Chrome
2. Tocá el menú (3 puntos)
3. "Agregar a pantalla de inicio"

### iOS:
1. Abrí el link en Safari
2. Tocá el botón compartir
3. "Agregar a pantalla de inicio"

## Archivos incluidos:
- `index.html` - App principal
- `manifest.json` - Configuración PWA
- `service-worker.js` - Funcionalidad offline
- `icon-192.png` - Ícono 192x192
- `icon-512.png` - Ícono 512x512

## Deploy en GitHub Pages:

1. Creá un repo en GitHub
2. Subí todos estos archivos
3. Andá a Settings > Pages
4. Source: Deploy from branch "main"
5. Tu app estará en: `https://tu-usuario.github.io/nombre-repo`

---
Desarrollado con Claude AI
